const http=require("http");
const express=require("express");
const bodyparser=require("body-parser");

//const Database=require("./certusMealServer/AdminLogin");
//const AdminLogin=require("./certusMealServer/AdminLogin");
//const AdminSignup=require("./certusMealServer/AdminSignup");

//const mongoClient = require("mongodb").MongoClient;
const passport=require("passport");
//const crypto=require("crypto");
//const express=require("express");
//const app=express();
const app=express();
app.use(passport.initialize());
app.use(passport.session());

app.use(bodyparser.urlencoded({extended:false}));
//app.use(bodyparser.json());


const fs=require("fs");
const crypto=require("crypto");
const mongoClient=require("mongodb").MongoClient;

let inspector={
    createAgent:(req,resp)=>{
        let paramsObj=JSON.parse(Object.keys(req.body));

        if(!paramsObj.name||!paramsObj.date||!paramsObj.signature||!paramsObj.batch)
         return resp.status(400).json({error:"fill all the fields"});

         console.log("new Agent creation initiated...");

        let Name=paramsObj.name;
        let batch=paramsObj.batch;
        let catholic=paramsObj.catholic;
        let date=paramsObj.date;
        let signature=paramsObj.signature;
        let hadLunch=paramsObj.eaten;
        let id2=paramsObj.id2; //since find() is not working

          //encrpting password using sha1 algorithm
            sha1=crypto.createHash("sha1");
            sha1.update(signature);
           passwdHash=sha1.digest("hex");

        const Agent={id2:id2,name:Name,signature:passwdHash,hadLunch:hadLunch,catholic:catholic,date:date,batch:batch};
        insertAgent(resp,user);//saving user
        saveAgent(Agent);
},
    deleteAgent:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        
        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

    //checking if user exists
    await collection.findOne({name:paramsObj.name})
                .then(agent=>{
                    collection.deleteOne(agent);
                },()=>{})
                .then(()=>{
                    console.log("Agent deleted successfully...");
                    resp.status(200).json({message:"Deleting successfull..."});
                });

                this.initializeTable();
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }
},
    updateDatabase:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        let count=paramsObj.length-1;
        let str='name,signature,hadLunch,batch,date,catholic\n';

        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

 do{ //iterating thru each agent
   await collection.findOne({name:paramsObj[count].id2}) //checking if user exists
                .then(agent=>{
                  if(agent!=null||undefined) {
                     collection.updateOne(paramsObj[count]); //updating existing users info
                     str+=(agent.name+","+agent.signature+","+agent.hadLunch+","+agent.batch+","+agent.catholic+"\n");
                    }
                     else if(paramsObj[count].new!=undefined) collection.insertOne(paramsObj[count]); //this a new agent 
                    else console.log("Unidentified item/agent data for: "+paramsObj[count].name); //incase unrecognized member..shud use create agent first
                    },()=>{});
                --count;
            }
            while(count>=0);

            saveAgent(str,true);
            console.log("Data update complete...");
            resp.status(200).json({message:"Data update complete..."});
            //end of try statement
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }

},
    getAgents:async function(req,resp){    
        let paramsObj=JSON.parse(Object.keys(req.body));
        let maxNo=1;
        let Farray=[]; //storing the result

        try{
                const client=new mongoClient("mongodb://localhost:27017");
                await client.connect();
        
          const dbName="certusAdmin";
          const collectionName="collection1";
        
          const db=client.db(dbName);
          const collection=db.collection(collectionName);
    
        //checking if user exists
       do{
        collection.findOne({id2:maxNo})
                    .then(agent=>{
                     if(agent!=null||undefined)   Farray.push(agent);
                     else {maxNo=undefined; PromiseRejectionEvent}
                    },()=>{})
                    .then(()=>{
                        ++maxNo;
                        console.log("Agent "+agent.name+" retrieved...");
                    },()=>console.log("Data retrieval finished..."))
                } while(maxNo!=undefined);
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }

    resp.status(200).json({data:Farray}); //list of agents returned
    },
    initializeTable:async function(req=true,resp=false){ //sending back data to the requesst source and saving also in txt file incase the req fails
        let id2=1; //starting point
        let str='name,signature,hadLunch,batch,date,catholic\n'; //tab separator;

        console.log("here");

        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

    do{ 
 await   collection.findOne({id2:id2})
                .then(agent=>{
                    if(agent!=null||undefined) str+=(agent.name+","+agent.signature+","+agent.hadLunch+","+agent.batch+","+agent.date+","+agent.catholic+"\n"); //this is a tab separator
                    else {id2=undefined; PromiseRejectionEvent}
                },()=>{})
                .then(()=>{
                    console.log("Agent "+id2+" retrieved...");
                    id2++;
                },()=>console.log("*********Data  retrieval finished..."))
               
    }
    while(id2!=undefined);

if(resp!=false) resp.status(200).json(str);
saveAgent(str,true);
}
    catch(e){
        console.log("Error ocurred: "+e);
    }
    }


}


//functions
async function insertAgent(resp,document){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="certusAdmin";
  const collectionName="collection1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
//checking if user exists
collection.findOne({name:document.name})
.then(data=>{
    try{
 if(data!=null) {
    console.log("Agent: "+data.name+" already exists...");
    flag=false; //alternative since promisereject is not working
    //return  PromiseRejectionEvent();
    }
else{console.log("creating new agent...")}}
catch(e){ console.log("Error in sync:"+e)}}
)
.then(function(){
    if(flag==true){
     collection.insertOne(document);
    console.log("Agent has been created successfully...");
    resp.json({message:"Agent has been created successfully..."})
    }
    else{
        resp.json({error:"operation failed..."});
        console.log("operation aborted...");
    }
},()=>{
    resp.json({error:"operation failed..."});
    console.log("operation aborted...")})  
}

    catch(e){ //user exists
        if(e.code==11000) console.log("document key error,this user(document) already exists...");
        else console.log("An unknown error occured"+e);
    }
  
}


let cnt=0;
async function saveAgent(agent,clean=false){
    try{
     await       fs.open("certusMealServer/excel.txt","w",(error)=>{
                if(error){
                    console.log("*******************error while erasing:"+error);
                    state1=true;
                    return false;
                }
                else{
                    console.log("*****************Erasing done....");
                    cnt++
                    return true;
                }
            })
//saving new data
   await fs.writeFile("certusMealServer/excel.txt",agent,(error)=>{
        if(error){
            console.log("*******************error while saving:"+error);
            state1=true;
            return false;
        }
        else{
            console.log("*****************Agent saved successfully....");
            cnt++;
            return true;
        }
    })
    }
    catch(e){
        throw(e)
    }
}


//signup
//const crypto=require("crypto");
//const mongoClient=require("mongodb").MongoClient;

let creator={
    createUser:(req,resp)=>{
        let paramsObj=JSON.parse(Object.keys(req.body));

        if(!paramsObj.name||!paramsObj.password1||!paramsObj.password2||!paramsObj.email)
         return resp.status(400).json({error:"fill all the fields"});

         console.log("new user creation initiated...");

        let Name=paramsObj.name;
        let passw1=paramsObj.password1;
        let pass2=paramsObj.password2;
        let sha1,passwdHash;

        if(passw1!=pass2){ resp.json("passwords do not match"); return console.log("failed...");}
        else{  //encrpting password using sha1 algorithm
            sha1=crypto.createHash("sha1");
            sha1.update(paramsObj.password1);
           passwdHash=sha1.digest("hex");
        }


        const user={name:Name,password:passwdHash,loggedIn:true};
        insertUser(resp,user);//saving user
}
}

//functions
async function insertUser(resp,document){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="certusAdmin";
  const collectionName="collection1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
//checking if user exists
collection.findOne({name:document.name})
.then(data=>{
    try{
 if(data!=null) {
    console.log("user: "+data.name+" already exists...");
    flag=false; //alternative since promisereject is not working
    //return  PromiseRejectionEvent();
    }
else{console.log("creating new user...")}}
catch(e){ console.log("Error in sync:"+e)}}
)
.then(function(){
    if(flag==true){
     collection.insertOne(document);
    console.log("user has been created successfully...");
    resp.json({message:"user has been created successfully..."})
    }
    else{
        resp.json({error:"operation failed..."});
        console.log("operation aborted...");
    }
},()=>{
    resp.json({error:"operation failed..."});
    console.log("operation aborted...")})  
}

    catch(e){ //user exists
        if(e.code==11000) console.log("document key error,this user(document) already exists...");
        else console.log("An unknown error occured"+e);
    }
  
}




//login
let  client={
    confirmUser:async function(req,resp){
        let name=req;
        console.log("--->"+name);

        let paramsObj=JSON.parse(Object.keys(req.body));
        console.log("user login initiated..."+Object.keys(req.body));

        try{
        if(!paramsObj.name||!paramsObj.password) return resp.status(400).json({message:"fill all the fields"});
        findUser(req,resp,paramsObj.name,paramsObj.password);
        }
        catch(e){console.log("error logging in: "+e)}
    },

    logoutUser:function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));

        LogOutUser(resp,paramsObj.name,paramsObj.password);
}
}


//functions
async function findUser(req,resp,username,password){  
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="certusAdmin";
  const collectionName="collection1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);

//checking if user exists
collection.findOne({name:username})
.then(data=>{
 if(data.name!=null) {   //user exists
    //passwordverify(password,data.password)
   
    collection.findOne({name:username}) //use->{name:username,password}  care here ,users might have the same password,there4 the creteria is important
    .then(dat=>{
        if(dat.password!=null) { //waiting for the verify crypto function..
            sha1=crypto.createHash("sha1");
            sha1.update(password);
           passwdHash=sha1.digest("hex");

           if(passwdHash!=dat.password) PromiseRejectionEvent();

            if(dat.loggedIn==true){
                console.log("user already logged in...");
                resp.status(400).json({error:"This user is alreay logged in..."});
            }
                 else{
            collection.findOneAndUpdate({name:username},{$set:{loggedIn:true}})
            .then(()=>{
                console.log("user logged in successfully...");
                resp.json({message:"done"});
               // resp.sendFile(path.resolve("","proxyPac","chargedDust.html")); 
            });
        }
         }
        else PromiseRejectionEvent() },()=>{console.log("user doesnot exist...");resp.status(400).json("user doesnot exist")})
        .then(()=>{},()=>{
            console.log("invalid password...")
            resp.status(400).json({message:"invalid password"});
        })
    }
else PromiseRejectionEvent()})


    .then(()=>{},()=>{
        console.log("invalid username...")
        resp.status(400).json({message:"invalid username"});
    })

    }
    catch(e){
        console.log("error while logging in.."+e)
    }
}


async function LogOutUser(resp,username,password){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="certusAdmin";
  const collectionName="collection1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
await collection.findOne({name:username})
                                .then(data=>{
                                    if(data.name!=null && data.password!=null){
                                        collection.findOneAndUpdate({name:username},{$set:{loggedIn:false}})
                                                    .then(()=>{
                                                        console.log("user logged out successfully..");
                                                        resp.json({message:"user logged out..."})
                                                    })
                                    }
                                    else PromiseRejectionEvent();
                                })
                                .then(()=>{},()=>{
                                    console.log("invalid username/password");
                                    resp.json({error:"invalid username/password"})
                                })

   
}
    catch(e){console.log("error while logging out:"+e)}
}




























const server=http.createServer(app);



app.post("/login",(req,resp)=>{ client.confirmUser(req,resp)});


app.get("/logout",(req,resp)=>{ client.logoutUser(req,resp)});


app.post("/signup",(req,resp)=>{ creator.createUser(req,resp)});


app.get("/getAgents",(req,resp)=>{ inspector.getAgents(req,resp)});


app.post("/addAgent",(req,resp)=>{ inspector.createAgent(req,resp)});


app.post("/backup",(req,resp)=>{ inspector.updateDatabase(req,resp)});


app.post("/deleteAgent",(req,resp)=>{ inspector.deleteAgent(req,resp)});

app.get("/retrieveData",(req,resp)=>{ inspector.initializeTable(req,resp)});

app.get("/ping",(req,resp)=>{resp.status(200).json({state:"active"})}); //call this in a given interval,to make sure the sever is reacheable


server.listen(2000,()=>{console.log("mealServer running at port:2000")});